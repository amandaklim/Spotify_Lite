class Artist < ActiveRecord::Base
  has_many :songs, class_name: 'Song', dependent: :destroy
  validates :name, presence: true

  def artist_search
    new_artist_name = name.gsub(/\s+/, '+')
    new_artist_name
  end

  def in_spotify?
    data = JSON.parse(open("https://api.spotify.com/v1/search?q=#{artist_search}&type=artist").read)
    artist_data = data['artists']
    !artist_data['items'].empty?
  end

  def add_song(artist_params)
    song_fields = artist_params[:song_attributes]
    new_song = Song.new(song_fields)
    new_song.artist = self
    if new_song.in_spotify? && self.in_spotify?
      songs.append(new_song) unless songs.include? new_song
      new_song.save
      true
    else
      false
    end
  end
end
