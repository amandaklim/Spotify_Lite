class Song < ActiveRecord::Base
  belongs_to :artist, class_name: 'Artist'
  validates :name, presence: true

  def in_spotify?
    data = JSON.parse(open("https://api.spotify.com/v1/search?q=#{song_search}&type=track").read)
    tracks_data = data['tracks']
    !tracks_data['items'].empty?
  end

  def song_search
    new_song_name = name.gsub(/\s+/, '+')
    new_artist_name = artist.name.gsub(/\s+/, '+')
    new_song_name + '+' + new_artist_name
  end

  def spotify_uri
    data = JSON.parse(open("https://api.spotify.com/v1/search?q=#{song_search}&type=track").read)
    return nil unless in_spotify?
    return data['tracks']['items'][1]['uri'] unless data['tracks']['items'][1]['uri'].empty?
    return nil if data['tracks']['items'][0]['uri'].empty?
  end

  def add_artist(song_params)
    artist_to_add = Artist.find(song_params[:artist_id])
    self.artist = artist_to_add
    if in_spotify?
      artist.songs.append(self) unless artist.songs.include? self
      save
      return true
    end
    false
  end
end
