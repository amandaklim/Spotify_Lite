class SongsController < ApplicationController
  before_action :set_song, only: [:show, :destroy]

  # GET /songs
  def index
    @songs = Song.all
  end

  # GET /songs/1
  def show
  end

  def all
    @songs = Song.all
  end

  # GET /songs/new
  def new
    @song = Song.new
  end

  # POST /songs
  def create
    @song = Song.new(name: song_params[:name])
    if @song.add_artist(song_params)
      redirect_to artist_song, notice: 'Song was successfully created.'
    else
      render :new
    end
  end

  # DELETE /songs/1
  def destroy
    @song.destroy
    redirect_to '/songs', notice: 'Song was successfully destroyed.'
  end

  private

  def set_song
    @song = Song.find(params[:id])
  end

  def song_params
    params.require(:song).permit(:name, :artist_id)
  end
end
