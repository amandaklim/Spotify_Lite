SpotifyJukebox::Application.routes.draw do
  root 'welcome#index'
  resources :artists do
    resources :songs
  end
  get '/songs' => 'song#all'
  post '/songs' => 'songs#create'
end
